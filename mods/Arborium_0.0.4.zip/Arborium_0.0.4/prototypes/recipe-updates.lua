if bobmods and bobmods.lib then
  if data.raw.item["glass"] then
    bobmods.lib.recipe.replace_ingredient("arborium-2", "copper-cable", "glass")
    bobmods.lib.recipe.replace_ingredient("arborium-3", "copper-cable", "glass")
  end
  if data.raw.item["fertilizer"] then
    bobmods.lib.recipe.replace_ingredient("arborium-3", "steel-plate", "fertilizer")
  end
end