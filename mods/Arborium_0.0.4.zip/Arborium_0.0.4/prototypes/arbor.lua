local mechacat="production-machine"
if data.raw["item-subgroup"]["environmental-machine"] then mechacat = "environmental-machine" end

data:extend(
{
 {
    type = "recipe-category",
    name = "arborium"
  },
  {
    type = "recipe-category",
    name = "mulchening"
  },
  {
    type = "item",
    name = "arborium",
    icon = "__base__/graphics/icons/root-b.png",
    flags = {"goes-to-quickbar"},
    subgroup = mechacat,
    order = "a[arbor]-a[arborium]",
    place_result = "arborium",
    stack_size = 50
  },
  {
    type = "item",
    name = "mulcher",
    icon = "__base__/graphics/icons/red-asterisk.png",
    flags = {"goes-to-quickbar"},
    subgroup = mechacat,
    order = "a[arbor]-b[mulcher]",
    place_result = "mulcher",
    stack_size = 50
  },
  {
    type = "recipe",
    name = "arborium",
    enabled = true,
    energy_required = 20,
    ingredients =
    {
      {"wood", 10},
	  {"iron-plate", 15},
	  {"copper-plate", 5}
    },
    result="arborium",
    icon = "__base__/graphics/icons/root-b.png",
    subgroup = mechacat,
    order = "a[arbor]-a[arborium]"
  },
  {
    type = "recipe",
    name = "mulcher",
    enabled = true,
    energy_required = 20,
    ingredients =
    {
      {"copper-cable", 5},
	  {"iron-gear-wheel", 10},
	  {"electronic-circuit", 1},
	  {"iron-axe", 3}
    },
    result="mulcher",
    icon = "__base__/graphics/icons/red-asterisk.png",
    subgroup = mechacat,
    order = "a[arbor]-b[mulcher]"
  },
  {
    type = "furnace",
    name = "arborium",
    icon = "__base__/graphics/icons/root-b.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "arborium"},
    max_health = 150,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    light = {intensity = 1, size = 10},
    resistances =
    {
      {
        type = "fire",
        percent = -25
      }
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    module_specification =
    {
      module_slots = 0,
      module_info_icon_shift = {0, 0.8}
    },
    allowed_effects = {"consumption", "speed", "productivity"},
    crafting_categories = {"arborium"},
    result_inventory_size = 1,
    crafting_speed = 1,
    energy_usage = "25kW",
    source_inventory_size = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = -0.005
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/electric-furnace.ogg",
        volume = 0.7
      },
      apparent_volume = 1.5
    },
    animation =
    {
      filename = "__Arborium__/graphics/arborium-base.png",
      priority = "high",
      width = 129,
      height = 100,
      frame_count = 1,
      shift = {0.421875, 0}
    },
    working_visualisations =
    {
      {
        animation =
        {
          filename = "__Arborium__/graphics/arborium-trees.png",
          priority = "high",
          width = 129,
          height = 100,
          frame_count = 1,
          animation_speed = 1.0,
          shift = {0.425, 0.0}
        }
      }
    }
  },
  {
    type = "furnace",
    name = "mulcher",
    icon = "__base__/graphics/icons/red-asterisk.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "mulcher"},
    max_health = 200,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    resistances =
    {
      {
        type = "fire",
        percent = 30
      }
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    fast_replaceable_group = "assembling-machine",
    animation =
    {
      filename = "__Arborium__/graphics/mulcher.png",
      priority="high",
      width = 99,
      height = 102,
      frame_count = 32,
      line_length = 8,
      shift = {0.25, -0.1}
    },
    crafting_categories = {"mulchening"},
    result_inventory_size = 3,
    source_inventory_size = 1,
    crafting_speed = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.05 / 1.5
    },
    energy_usage = "80kW",
    ingredient_count = 1,
    open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = {
        {
          filename = "__base__/sound/assembling-machine-t1-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t1-2.ogg",
          volume = 0.8
        },
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5,
    }
  },
  {
    type = "item",
    name = "arborium-2",
    icon = "__base__/graphics/icons/root-b.png",
    flags = {"goes-to-quickbar"},
    subgroup = mechacat,
    order = "a[arbor]-a[arborium-2]",
    place_result = "arborium-2",
    stack_size = 50
  },
  {
    type = "item",
    name = "arborium-3",
    icon = "__base__/graphics/icons/root-b.png",
    flags = {"goes-to-quickbar"},
    subgroup = mechacat,
    order = "a[arbor]-a[arborium-3]",
    place_result = "arborium-3",
    stack_size = 50
  },
  {
    type = "item",
    name = "mulcher-2",
    icon = "__base__/graphics/icons/red-asterisk.png",
    flags = {"goes-to-quickbar"},
    subgroup = mechacat,
    order = "a[arbor]-b[mulcher-2]",
    place_result = "mulcher-2",
    stack_size = 50
  },
  {
    type = "recipe",
    name = "arborium-2",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"wood", 25},
	  {"steel-plate", 20},
	  {"copper-cable", 10},
      {"arborium", 1}
    },
    result="arborium-2",
    icon = "__base__/graphics/icons/root-b.png",
    subgroup = mechacat,
    order = "a[arbor]-a[arborium-2]"
  },
  {
    type = "recipe",
    name = "arborium-3",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"wood", 50},
	  {"steel-plate", 10},
	  {"copper-cable", 15},
	  {"plastic-bar", 10},
      {"arborium-2", 1}
    },
    result="arborium-3",
    icon = "__base__/graphics/icons/root-b.png",
    subgroup = mechacat,
    order = "a[arbor]-a[arborium-3]"
  },
  {
    type = "recipe",
    name = "mulcher-2",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"mulcher", 1},
	  {"advanced-circuit", 5},
	  {"steel-axe", 5}
    },
    result="mulcher-2",
    icon = "__base__/graphics/icons/red-asterisk.png",
    subgroup = mechacat,
    order = "a[arbor]-b[mulcher-2]"
  },
  {
    type = "furnace",
    name = "arborium-2",
    icon = "__base__/graphics/icons/root-b.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "arborium-2"},
    max_health = 300,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    light = {intensity = 1, size = 10},
    resistances =
    {
      {
        type = "fire",
        percent = -25
      }
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    module_specification =
    {
      module_slots = 0,
      module_info_icon_shift = {0, 0.8}
    },
    allowed_effects = {"consumption", "speed", "productivity"},
    crafting_categories = {"arborium"},
    result_inventory_size = 1,
    crafting_speed = 1.75,
    energy_usage = "25kW",
    source_inventory_size = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = -0.005
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/electric-furnace.ogg",
        volume = 0.7
      },
      apparent_volume = 1.5
    },
    animation =
    {
      filename = "__Arborium__/graphics/arborium-base.png",
      priority = "high",
      width = 129,
      height = 100,
      frame_count = 1,
      shift = {0.421875, 0}
    },
    working_visualisations =
    {
      {
        animation =
        {
          filename = "__Arborium__/graphics/arborium-trees.png",
          priority = "high",
          width = 129,
          height = 100,
          frame_count = 1,
          animation_speed = 1.0,
          shift = {0.425, 0.0}
        }
      }
    }
  },
  {
    type = "furnace",
    name = "arborium-3",
    icon = "__base__/graphics/icons/root-b.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "arborium-3"},
    max_health = 400,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    light = {intensity = 1, size = 10},
    resistances =
    {
      {
        type = "fire",
        percent = -20
      }
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    module_specification =
    {
      module_slots = 0,
      module_info_icon_shift = {0, 0.8}
    },
    allowed_effects = {"consumption", "speed", "productivity"},
    crafting_categories = {"arborium"},
    result_inventory_size = 1,
    crafting_speed = 2.5,
    energy_usage = "23kW",
    source_inventory_size = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = -0.005
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/electric-furnace.ogg",
        volume = 0.7
      },
      apparent_volume = 1.5
    },
    animation =
    {
      filename = "__Arborium__/graphics/arborium-base.png",
      priority = "high",
      width = 129,
      height = 100,
      frame_count = 1,
      shift = {0.421875, 0}
    },
    working_visualisations =
    {
      {
        animation =
        {
          filename = "__Arborium__/graphics/arborium-trees.png",
          priority = "high",
          width = 129,
          height = 100,
          frame_count = 1,
          animation_speed = 1.0,
          shift = {0.425, 0.0}
        }
      }
    }
  },
  {
    type = "furnace",
    name = "mulcher-2",
    icon = "__base__/graphics/icons/red-asterisk.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "mulcher-2"},
    max_health = 400,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    resistances =
    {
      {
        type = "fire",
        percent = 30
      }
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    module_specification =
    {
      module_slots = 2,
      module_info_icon_shift = {0, 0.8}
    },
    fast_replaceable_group = "assembling-machine",
    animation =
    {
      filename = "__Arborium__/graphics/mulcher.png",
      priority="high",
      width = 99,
      height = 102,
      frame_count = 32,
      line_length = 8,
      shift = {0.25, -0.1}
    },
    crafting_categories = {"mulchening"},
    result_inventory_size = 3,
    source_inventory_size = 1,
    crafting_speed = 1.75,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.05 / 1.5
    },
    energy_usage = "110kW",
    ingredient_count = 1,
    open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = {
        {
          filename = "__base__/sound/assembling-machine-t1-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t1-2.ogg",
          volume = 0.8
        },
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5,
    }
  }
}
)