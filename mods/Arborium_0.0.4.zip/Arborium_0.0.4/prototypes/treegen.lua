local function index_to_letter(index, starting_at)
  return string.char(string.byte(starting_at or "a", 1) - 1 + index)
end

local function AddLootToEntity(entityType, entityName, itemName, probability, countMin, countMax)
	if data.raw[entityType] ~= nil then
		if data.raw[entityType][entityName] ~= nil then
			if data.raw[entityType][entityName].loot == nil then
				data.raw[entityType][entityName].loot = {}
			end
			table.insert(data.raw[entityType][entityName].loot, {item = itemName, probability = probability, count_min = countMin, count_max = countMax})
		end
	end
end
--[[local function AddResToEntity(entityType, entityName, itemName, amount)
	if data.raw[entityType] ~= nil then
		if data.raw[entityType][entityName] ~= nil then
			if data.raw[entityType][entityName].minable.results == nil then
				data.raw[entityType][entityName].minable.results = {{data.raw[entityType][entityName].minable.result, data.raw[entityType][entityName].minable.count}}
				data.raw[entityType][entityName].minable.result=nil
				data.raw[entityType][entityName].minable.count=nil
			end
			table.insert(data.raw[entityType][entityName].minable.results, {itemName, amount})
		end
	end
end]]

for i, tree_data in pairs(data.raw["tree"]) do
  --local type_number = string.format("%02d", tree_data.type)
  --local type_name = "tree-" .. type_number
  local name = i
  if string.find(name, "dead-") == nil then
  data:extend(
  {--[[
   {
      type = "tree",
      name = name,
      icon = "__base__/graphics/icons/" .. type_name .. ".png",
      flags = {"placeable-neutral", "placeable-off-grid", "breaths-air"},
      minable =
      {
        mining_particle = "wooden-particle",
        mining_time = 2,
        results = {{"raw-wood", 4},{name.."-seeds", 2}}
      },
      corpse = type_name .. "-stump",
      remains_when_mined = type_name .. "-stump",
      emissions_per_tick = -0.0005,
      max_health = 50,
      collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
      selection_box = {{-0.9, -2.2}, {0.9, 0.6}},
      drawing_box = tree_data.drawing_box,
      subgroup = "trees",
      order = "a[tree]-a[regular]-" .. order,
      vehicle_impact_sound =  { filename = "__base__/sound/car-wood-impact.ogg", volume = 1.0 },
      autoplace = autoplace_settings(tree_data.autoplace_peaks, tree_data.autoplace_extra),
      variations = tree_variations,
      colors = tree_data.colors
    },]]
  {
    type = "item",
    name = name.."-sapling",
    icon = tree_data.icon,
    flags = {"goes-to-quickbar"},
    subgroup = "trees",
    order = "a-c["..name.."]",
    place_result = name,
    stack_size = 100
  },
  {
    type = "item",
    name = name.."-seeds",
    icon = "__base__/graphics/icons/root-a.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "trees",
    order = "a-c["..name.."]",
    stack_size = 500
  },
  {
    type = "recipe",
    name = name.."-sapling",
	category = "arborium",
    enabled = true,
	hidden = true,
    energy_required = 30,
    ingredients =
    {
      {name.."-seeds", 1}
    },
    result=name.."-sapling",
    icon = tree_data.icon,
    subgroup = "trees",
    --order = "a[oil-processing]-a[basic-oil-processing]"
  },
  {
    type = "recipe",
    name = "mulch-" .. name,
    enabled = true,
	hidden = true,
	category = "mulchening",
    energy_required = 10,
    ingredients =
    {
      {name.."-sapling", 1}
    },
    results=
	{
		{type = "item", name = "raw-wood", amount_min = 3, amount_max = 4},
		{type = "item", name = name.."-seeds", amount_min = 1, amount_max = 3}
	},
	main_product="raw-wood",
    subgroup = "trees",
    --order = "a[oil-processing]-a[basic-oil-processing]"
  },
  {
	type = "recipe",
	name = name.."-seeds-to-wood",
	category = "smelting",
	enabled = true,
	hidden = true,
	energy_required = 2,
	ingredients =
	{
	  {name.."-seeds", 4}
	},
	result = "wood"
  }
  })
  AddLootToEntity("tree",name,name.."-seeds",.5,1,2)
  if tree_data.minable.results then
  table.insert(data.raw["tree"][i].minable.results, {name.."-seeds", 2})
  else
  data.raw.tree[i].minable=
      {
        mining_particle = "wooden-particle",
        mining_time = 2,
        results = {{data.raw.tree[i].minable.result, data.raw.tree[i].minable.count},{name.."-seeds", 2}}
      }
	end
  --AddResToEntity("tree",name,name.."-seeds",.5,1,2)
  --[[
  if tree_data.minable.results then
	table.insert
  end
  ]]
  end
end