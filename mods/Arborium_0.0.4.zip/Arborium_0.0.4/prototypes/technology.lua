data:extend({
{
  type = "technology",
  name = "dendrology",--Dendrology
  icon = "__core__/graphics/neutral-force-icon.png",
  icon_size = 128,
  effects =
  {
	{
      type = "unlock-recipe",
      recipe = "arborium-2"
	}
  },		 
  unit =
  {
    count = 20,
    ingredients = {
	  {"science-pack-1", 1}
	},
    time = 10
  },
  upgrade=true
},
{
  type = "technology",
  name = "dendrology-2",
  icon = "__core__/graphics/neutral-force-icon.png",
  icon_size = 128,
  prerequisites = {"dendrology"},
  effects =
  {
	{
      type = "unlock-recipe",
      recipe = "arborium-3"
	},
	{
      type = "unlock-recipe",
      recipe = "mulcher-2"
	}
  },		 
  unit =
  {
    count = 50,
    ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1}
	},
    time = 15
  },
  upgrade=true
}
})