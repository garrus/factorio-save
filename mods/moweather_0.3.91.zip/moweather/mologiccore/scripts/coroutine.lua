--coroutine.create(function)
--coroutine.yield()
--coroutine.resume(MyCoroutine)
--coroutine.status(MyCoroutine)

--suspended
--dead
